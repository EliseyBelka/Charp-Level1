﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les3
{
    class Task2b
    {
        static void Pause()
        {
            Console.SetCursorPosition(0, Console.WindowHeight - 2);
            Console.WriteLine("Press ESC to exit");
            while (Console.ReadKey().Key != ConsoleKey.Escape) ;
        }

        private static bool CheckNumber(string value)
        {
            double number;
            return double.TryParse(value, out number);
            
        }
    
        static void Main(string[] args)
        {
            string answer,StNum=null;
            double number=-1, sum=0;
            Console.WriteLine("Enter the numbers.The end of the input is the number 0.");
            while (number != 0)
            {
                answer = Console.ReadLine();
                if (answer == "0") break; else
                if (CheckNumber(answer) != false)
                {
                    double.TryParse(answer, out number);
                    if ((number > 0) & (number % 2 != 0))
                    {
                        StNum = StNum + answer + ' ';
                        sum += number;
                    }
                }                                                             
                else                                                          
                {                                                             
                    Console.WriteLine("Incorrect data entered.Try again");    
                }                                                             
            }
            Console.WriteLine($"Numbers:{StNum}\nAmount:{sum}");
            Pause();
        }
    }
}
