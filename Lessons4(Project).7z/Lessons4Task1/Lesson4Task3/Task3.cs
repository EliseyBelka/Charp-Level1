﻿////ЗАДАНИЕ И АВТОР
////а) Дописать класс для работы с одномерным массивом.Реализовать конструктор, создающий массив определенного размера и заполняющий массив числами от начального значения с заданным шагом.Создать свойство Sum, которое возвращает сумму элементов массива, метод Inverse, возвращающий новый массив с измененными знаками у всех элементов массива(старый массив, остается без изменений),  метод Multi, умножающий каждый элемент массива на определённое число, свойство MaxCount, возвращающее количество максимальных элементов.
////б)** Создать библиотеку содержащую класс для работы с массивом.Продемонстрировать работу библиотеки
////е) *** Подсчитать частоту вхождения каждого элемента в массив(коллекция Dictionary<int, int>)
////исполнено 
////АВТОР исполнения Белканов Алексей

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson4Task3
{
    class Task3
    { /// <summary>
      ///Великая пауза))) 
      /// </summary>
        private static void Pause()
        {
            Console.SetCursorPosition(0, Console.WindowHeight - 2);
            Console.WriteLine("Press ESC to exit");
            while (Console.ReadKey().Key != ConsoleKey.Escape) ;
        }
        private static void Main(string[] args)
        {
            OneDimArr array1 = new OneDimArr(10,2,5);
            Console.WriteLine(array1);
            for (int i = 0; i < 10; i++)
                Console.WriteLine(array1);
            
            Pause();
        }
    }
}
