﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson4Task3
{/// <summary>
/// Массив при вызове указать: размер, начальное значение, шаг
/// </summary>
    class OneDimArr
    {
        int[] Temporary;

        public OneDimArr (int Size, int InitialValue, int Step)
        {
            Temporary = new int[Size];
            for (int i = 0; i < Size; i++)
            {
                Temporary[i] = InitialValue;
                InitialValue += Step;
            }
            return;
        }
    }
}
