﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les3
{
    class Task3
    {
        /// <summary>
        /// Старая добрая пауза
        /// </summary>
        static void Pause()
        {
            Console.SetCursorPosition(0, Console.WindowHeight - 2);
            Console.WriteLine("Press ESC to exit");
            while (Console.ReadKey().Key != ConsoleKey.Escape) ;
        }

        static string PrintFract(Fractional temp)
        {
           // Console.WriteLine($"{temp.numerator}/{temp.denominator}");
            return $"{temp.numerator}/{temp.denominator}";
        }

        static void Main(string[] args)
        {
          Fractional Fraction1 = new Fractional();
          Fractional Fraction2 = new Fractional();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\"b\"Must not be 0 (division by 0 is not allowed)");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Enter the first fraction as a/b.");
            Console.ResetColor();
            Fraction1 =  Fractional.FormFract(Console.ReadLine());
            // Fraction1.numerator= 1;
            // Fraction1.denominator = 1;
            // PrintFract(Fraction1);

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\"d\"Must not be 0 (division by 0 is not allowed)");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Enter the second fraction as c/d.");
            Console.ResetColor();
            Fraction2 = Fractional.FormFract(Console.ReadLine());
            // Fraction2.numerator = 1;
            // Fraction2.denominator = 0;
            // PrintFract(Fraction2);

            Console.WriteLine("Sum of two numbers {0}+{1} = {2}", 
                PrintFract(Fraction1), PrintFract(Fraction2),
               PrintFract(Fractional.Reduction(Fractional.Addition(Fraction1, Fraction2))));

            Console.WriteLine("Difference of two numbers {0}-{1} = {2}",
               PrintFract(Fraction1), PrintFract(Fraction2), 
               PrintFract(Fractional.Reduction(Fractional.Difference(Fraction1, Fraction2))));

            Console.WriteLine("Multiplying of two numbers {0}*{1} = {2}",
               PrintFract(Fraction1), PrintFract(Fraction2), 
               PrintFract(Fractional.Reduction(Fractional.Multiplying(Fraction1, Fraction2))));

            Console.WriteLine("Divisiong of two numbers {0}/{1} = {2}",
               PrintFract(Fraction1), PrintFract(Fraction2), 
               PrintFract(Fractional.Reduction(Fractional.Divisiong(Fraction1, Fraction2))));

            Pause();
        }
    }
}
