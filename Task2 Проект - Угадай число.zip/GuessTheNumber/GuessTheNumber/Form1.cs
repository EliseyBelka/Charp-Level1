﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuessTheNumber
{
    public partial class Form1 : Form
    {
        int number,attempt=0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox2.Visible = false;
            Random rnd = new Random();
            number = rnd.Next(100);
            textBox2.Text = number.ToString();
            label2.Text = "Попытка:"+attempt.ToString();
        }

      
        private void label2_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Visible == true) textBox2.Visible = false;
            else textBox2.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == number.ToString())
                {
                    attempt++;
                    label2.Visible = false;
                    label1.Text = $"Поздравляем вы угадали. Попыток {attempt}";
                    button1.Visible = false;
                    textBox1.Visible = false;
                }
                if (int.Parse(textBox1.Text) > number)
                {
                    attempt++;
                    label2.Text = "Попытка:" + (attempt).ToString();
                    label1.Text = "Введите число меньше указанного";
                }
                    
                if (int.Parse(textBox1.Text) < number)
                {
                    attempt++;
                    label2.Text = "Попытка:" + (attempt).ToString();
                    label1.Text = "Введите число больше указанного";
                }
            }
            catch (System.FormatException)
            { Console.WriteLine("Не верный формат данных"); }
        }
           
        
    }
}
