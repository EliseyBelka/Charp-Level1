﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les3
{
    class Task2a
    {
        static void Pause()
        {
            Console.SetCursorPosition(0, Console.WindowHeight - 2);
            Console.WriteLine("Press ESC to exit");
            while (Console.ReadKey().Key != ConsoleKey.Escape) ;
        }

        private static bool CheckNumber(string value)
        {
            double number;
            return double.TryParse(value, out number);
        }

        static void Main(string[] args)
        {
            string answer, StNum = null;
            double number = -1, sum = 0;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Enter the numbers.The end of the input is the number 0.");
            Console.ResetColor();
            while (number != 0)
            {
                answer = Console.ReadLine();

                if ((double.TryParse(answer, out number) != false)) //task2a
                {
                    if ((number > 0) & (number % 2 != 0))
                    {
                        StNum = StNum + answer + ' ';
                        sum += number;
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Incorrect data entered.\nThe program is closed due to incorrect data.\nResult on already entered data:");
                    Console.ResetColor();
                }
            }
            double.TryParse(sum.ToString("N3"), out number); //task2a
            if (number != 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"Numbers:{StNum}\nAmount:{sum}");
                Console.ResetColor();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Data has not been entered correct.");
                Console.ResetColor();
            }
            Pause();
        }
    }
}
