﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les3
{
    public class Fractional
    {
        public int numerator;
        public int denominator;
        

        /// <summary>
        /// Принимает дробь в виде a/b отделяя числитель и знаменатель
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static Fractional FormFract(string s)
        {
            Fractional Temp = new Fractional();
            string[] FractParts = s.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            Temp.numerator = int.Parse(FractParts[0]);
            Temp.denominator = int.Parse(FractParts[1]);
            return Temp;
        }

        /// <summary>
        /// Нахождение Наибольшего Общего Делителя двух чисел
        /// </summary>
        /// <param name="FDen"></param>
        /// <param name="SDen"></param>
        /// <returns></returns>
        static int NOD(int FDen, int SDen)
        {  
                if (SDen == 0)
                    return FDen;
                else
                    return NOD(SDen, FDen % SDen);
        }
        /// <summary>
        /// Нахождение Наименьшего Общего Кратного двух чисел
        /// </summary>
        /// <param name="FDen"></param>
        /// <param name="SDen"></param>
        /// <returns></returns>
        static int NOK (int FDen, int SDen)
        {
            return Math.Abs(FDen * SDen) / NOD(FDen, SDen);
        }

        /// <summary>
        /// Операция сложения двух дробей вида (а/b) + (c/d)
        /// </summary>
        /// <param name="Sign"></param>
        /// <returns></returns>
        ///  
        public static Fractional Addition (Fractional First, Fractional Second)
        {
            Fractional Temp = new Fractional();
            try
            {
                int Anok = NOK(First.denominator, Second.denominator);
                Temp.numerator = First.numerator * Anok / First.denominator + Second.numerator * Anok / Second.denominator;
                Temp.denominator = Anok;
                return Temp;
            }
            catch
            {
                //ArgumentException attention = new ArgumentException(); не хватило информации как применить
                Console.WriteLine("Знаменатель не может быть равен 0");
                Temp.numerator = 0;
                Temp.denominator = 0;
                return Temp;
            }
            
        }
        /// <summary>
        /// Операция разность двух дробей вида (а/b) - (c/d)
        /// </summary>
        /// <param name="Sign"></param>
        /// <returns></returns>
        ///  
        public static Fractional Difference (Fractional First, Fractional Second)
        {
            Fractional Temp = new Fractional();
            try
            {
                int Dnok;
                Dnok = NOK(First.denominator, Second.denominator);
                Temp.numerator = First.numerator * Dnok / First.denominator - Second.numerator * Dnok / Second.denominator;
                Temp.denominator = Dnok;
                return Temp;
                }
            catch
            {
                //ArgumentException attention = new ArgumentException(); не хватило информации как применить
                Console.WriteLine("Знаменатель не может быть равен 0");
                Temp.numerator = 0;
                Temp.denominator = 0;
                return Temp;
            }
        }
        /// <summary>
        /// Операция умножения двух дробей вида (а/b) * (c/d)
        /// </summary>
        /// <param name="Sign"></param>
        /// <returns></returns>
        public static Fractional Multiplying (Fractional First, Fractional Second)
        {
            Fractional Temp = new Fractional();
            Temp.numerator = First.numerator * Second.numerator;
            Temp.denominator = First.denominator * Second.denominator;
            return Temp;
        }
        /// <summary>
        /// Операция деление двух дробей вида (а/b) / (c/d)
        /// </summary>
        /// <param name="Sign"></param>
        /// <returns></returns>
        public static Fractional Divisiong (Fractional First, Fractional Second)
        {
            Fractional Temp = new Fractional();
            Temp.numerator = First.numerator * Second.denominator;
            Temp.denominator = First.denominator * Second.numerator;
            return Temp;
        }

        /// <summary>
        /// Метод сокращения дробей
        /// </summary>
        /// <param name="Sign"></param>
        /// <returns></returns>
        ///  
        public static Fractional Reduction(Fractional Reduc)
        {
            Fractional Temp = new Fractional();
            int NodFract = NOD(Reduc.numerator, Reduc.denominator);
            Temp.numerator = Reduc.numerator / NodFract;
            Temp.denominator = Reduc.denominator / NodFract;
            return Temp;
        }

    }
}
