﻿ing System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson3Task1a
{
    struct Complex
    {
        public double im;
        public double re;

        #region "Operations with complex numbers"

        /// <summary>
        /// Сумма комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Plus(Complex ab, Complex cd)
        {
            Complex Temporary;
            Temporary.re = ab.re + cd.re;
            Temporary.im = ab.im + cd.im;
            return Temporary;
        }
        /// <summary>
        /// /// Разность комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Minus(Complex ab, Complex cd)
        {
            Complex Temporary;
            Temporary.re = ab.re - cd.re;
            Temporary.im = ab.im - cd.im;
            return Temporary;
        }
        /// <summary>
        /// Произведение комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Produce(Complex ab, Complex cd)
        {
            Complex Temporary;
            Temporary.re = (ab.re * cd.re) - (ab.im * cd.im);
            Temporary.im = (ab.re * cd.im) + (ab.im * cd.re);
            return Temporary;
        }
        /// <summary>
        /// Произведение комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Division(Complex ab, Complex cd)
        {
            Complex Temporary;
            Temporary.re = (((ab.re * cd.re) + (ab.im * cd.im)) / (Math.Pow(ab.im, 2) + Math.Pow(cd.im, 2)));
            Temporary.im = (((ab.im * cd.re) - (ab.re * cd.im)) / (Math.Pow(ab.im, 2) + Math.Pow(cd.im, 2)));
            return Temporary;
        }

        #endregion

        #region "Output the result of the operation"
        public string ToString(string Sign)
        {
            switch (Sign)
            {
                case "-": return re + "+" + im + "i";
                case "+": return re + "+" + im + "i";
                case "*": return re + "+" + im + "i";
                case "/": return re + "+" + im + "i";
                default: return "Invalid data entry";
            }

        }
        #endregion
    }

    class Task1a
    {
        static void Main(string[] args)
        {
            Complex complex1 = new Complex(); ;
            //complex1.re = 7;
            //complex1.im = 1;
            Console.WriteLine("The complex number is presented as:\na+bi");
            Console.Write("Enter a (real part) first value: ");
            complex1.re = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter b (imaginary part) first value: "); ;
            complex1.im = Convert.ToDouble(Console.ReadLine());

            Complex complex2 = new Complex();
            //complex2.re = 2;
            //complex2.im = 2;
            Console.Write("Enter a (real part) first value: ");
            complex2.re = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter b (imaginary part) first value: "); ;
            complex2.im = Convert.ToDouble(Console.ReadLine());

            // Complex result = complex1.Plus(complex2);
            Complex resultPl = Complex.Plus(complex1, complex2);
            Console.Write($"({complex1.re}+{complex1.im}i)+({complex2.re}+{complex2.im}i)=");
            Console.WriteLine(resultPl.ToString("+"));

            //result = complex1.Minus(complex2);
            Complex resultMi = Complex.Minus(complex1, complex2);
            Console.Write($"({complex1.re}+{complex1.im}i)-({complex2.re}+{complex2.im}i)=");
            Console.WriteLine(resultMi.ToString("-"));

            // result = complex1.Produce(complex2);
            Complex resultPr = Complex.Produce(complex1, complex2);
            Console.Write($"({complex1.re}+{complex1.im}i)*({complex2.re}+{complex2.im}i)=");
            Console.WriteLine(resultPr.ToString("*"));

            //result = complex1.Division(complex2);
            Complex resultDi = Complex.Division(complex1, complex2);
            Console.Write($"({complex1.re}+{complex1.im}i)/({complex2.re}+{complex2.im}i)=");
            Console.WriteLine(resultDi.ToString("/"));

            Console.ReadLine();
        }

    }
}

