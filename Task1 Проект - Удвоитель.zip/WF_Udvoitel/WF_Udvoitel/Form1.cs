﻿using System;
using System.Windows.Forms;

namespace WF_Udvoitel
{
    public partial class Form1 : Form
    {
        int counter=0; //счетчик числа команд
        
        int num = 30; //угадываеммое число
        int[] UndoOperation = { };
        public Form1()
        {
            InitializeComponent();
            CounterLBL.Text = "Выполнено команд:" + (counter++).ToString();
            //отключение кнопок до запуска игры через меню
            btnCommand1.Enabled = false;
            btnCommand2.Enabled = false;
            btnReset.Enabled = false;
            UndoMove.Enabled = false;
        }
        /// <summary>
        /// Обработка нажатия кнопки +1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCommand1_Click(object sender, EventArgs e)
        {
            if (counter == 0)//активация кнопки в случае если пользователь отменил ходы дальше 0
            {
                btnReset.Enabled = true;
                UndoMove.Enabled = true;
            } 
            //арифметическая операция над чилом в лебле
            lblNumber.Text = (int.Parse(lblNumber.Text) + 1).ToString();
            //счетчик количества операций
            counter++;//!!!если counter++ расположить сразу в CounterLBL.Text первая операция не учитывается
            CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
            //увеличение массива операций и занесенеи новой операции
            Array.Resize(ref UndoOperation,counter);
            UndoOperation[counter-1] = 1;
            if (lblNumber.Text == "30")
            {
                DialogResult result = MessageBox.Show("Число получено." + CounterLBL.Text);

            } 
        }
        /// <summary>
        /// Обработка нажатия кнопки  х2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCommand2_Click(object sender, EventArgs e)
        {
            if (counter == 0)
            {
                btnReset.Enabled = true;
                UndoMove.Enabled = true;
            }
            lblNumber.Text = (int.Parse(lblNumber.Text) * 2).ToString();
            counter++;
            CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
            Array.Resize(ref UndoOperation, counter);
            UndoOperation[counter-1] = 2;
            if (lblNumber.Text == "30")
            {
                DialogResult result = MessageBox.Show("Число получено." + CounterLBL.Text);
            }
        }
        /// <summary>
        /// Обработка кнопки СБРОС
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnReset_Click(object sender, EventArgs e)
        {
            if (counter > 0)
            {
                btnReset.Enabled = true;
                UndoMove.Enabled = true;
                counter++;
                Array.Resize(ref UndoOperation, counter);
                UndoOperation[counter - 1] = -int.Parse(lblNumber.Text);

                lblNumber.Text = "0";
                CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
            }
        }
        /// <summary>
        /// Отвечает за октрытия пункта меню ИГРАТЬ (создание новой игры)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void игратьToolStripMenuItem_Click(object sender, EventArgs e)
        {
          //  Visible = false;    //скрыть окно игры
            string mess = $"За минимальнео количество ходов Вы должны получить число {num} ";
            string caption = "Правила.";
            DialogResult result=MessageBox.Show(mess, caption, MessageBoxButtons.OK,MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            { 
                //активировать кнопки игры
                btnCommand1.Enabled = true;
                btnCommand2.Enabled = true;
                //сброс всех результатов
                counter = 0;
                lblNumber.Text = "0";
                CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
          //      Visible = true; //открыть окно игры
            }
        }
        /// <summary>
        /// Обработка кнопки ОТМЕНА ХОДА
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UndoMove_Click(object sender, EventArgs e)
        {

            if (counter== 0)
            {
                UndoMove.Enabled = false;
                btnReset.Enabled = false;
            } 
            else
            {
                if ((counter - 1 !=-1) & (UndoOperation[counter - 1] <=0))
                {
                    lblNumber.Text = (-UndoOperation[counter - 1]).ToString();
                    counter--;
                    CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
                }else
                if ((counter - 1 != -1) & (UndoOperation[counter - 1] == 1))
                {
                    lblNumber.Text = (int.Parse(lblNumber.Text) - 1).ToString();
                    counter--;
                    CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
                }
                else
                if ((counter - 1 != -1) & (UndoOperation[counter - 1] == 2))
                {
                    lblNumber.Text = (int.Parse(lblNumber.Text) / 2).ToString();
                    counter--;
                    CounterLBL.Text = "Выполнено команд:" + (counter).ToString();
                }              
            }
            
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
