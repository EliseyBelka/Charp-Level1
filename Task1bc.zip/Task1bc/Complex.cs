﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lesson3Task1a
{
    public class Complex
    {
        public double im;
        public double re;
        static Complex Temporary = new Complex();

        #region "Operations with complex numbers"

        /// <summary>
        /// Сумма комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Plus(Complex ab, Complex cd)
        {
            //Complex Temporary = new Complex();
            Temporary.re = ab.re + cd.re;
            Temporary.im = ab.im + cd.im;
            return Temporary;
        }
        /// <summary>
        /// /// Разность комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Minus(Complex ab, Complex cd)
        {
           // Complex Temporary = new Complex(); 
            Temporary.re = ab.re - cd.re;
            Temporary.im = ab.im - cd.im;
            return Temporary;
        }
        /// <summary>
        /// Произведение комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Produce(Complex ab, Complex cd)
        {
            //Complex Temporary = new Complex(); ;
            Temporary.re = (ab.re * cd.re) - (ab.im * cd.im);
            Temporary.im = (ab.re * cd.im) + (ab.im * cd.re);
            return Temporary;
        }
        /// <summary>
        /// Произведение комплексных чисел.
        /// </summary>
        /// <param name="x"></param>
        /// <returns></returns>
        public static Complex Division(Complex ab, Complex cd)
        {
           // Complex Temporary = new Complex(); 
            Temporary.re = (((ab.re * cd.re) + (ab.im * cd.im)) / (Math.Pow(ab.im, 2) + Math.Pow(cd.im, 2)));
            Temporary.im = (((ab.im * cd.re) - (ab.re * cd.im)) / (Math.Pow(ab.im, 2) + Math.Pow(cd.im, 2)));
            return Temporary;
        }

        #endregion

        #region "Output the result of the operation"
        public string ToString(string Sign)
        {
            switch (Sign)
            {
                case "-": return re + "+" + im + "i";
                case "+": return re + "+" + im + "i";
                case "*": return re + "+" + im + "i";
                case "/": return re + "+" + im + "i";
                default: return "Invalid data entry";
            }

        }
        #endregion
    }

}
